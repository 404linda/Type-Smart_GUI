from type_smart.core.logic import process_text

def test_process_text():
    assert process_text("hi") == "HI"
