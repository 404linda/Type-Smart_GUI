from type_smart.gui.windows import MainWindow

def run():
    app = MainWindow()
    app.start()

if __name__ == "__main__":
    run()
