def load_preset():
    return {"example": "preset loaded"}
