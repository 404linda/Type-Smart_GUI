def process_text(text: str) -> str:
    return text.upper()
