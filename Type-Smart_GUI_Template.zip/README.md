# Type-Smart GUI

A graphical interface for intelligent typing tools.
